stickUp
=======
a jQuery plugin

A simple plugin that "sticks" an element to the top of the browser window while scrolling past it, always keeping it in view. This plugin works on multi-page sites, but has additional features for one-pager layouts.

Please Visit the <a href="http://lirancohen.github.io/stickUp">GitHub Page</a> for installation instructions.